// src/services/firestoreService.ts
import {
  collection, doc, addDoc, updateDoc, deleteDoc,
  getDocs, getDoc, query, where, orderBy, Timestamp,
  onSnapshot, type Unsubscribe,
} from 'firebase/firestore'
import { db } from './firebase'

// ─── Type Definitions ────────────────────────────────────────────────────────

export type EventStatus = 'planejando' | 'em_andamento' | 'concluido' | 'cancelado'
export type EventType   = 'culto' | 'retiro' | 'conferencia' | 'acao_social' | 'reuniao' | 'outro'

export interface Event {
  id?: string
  userId: string
  churchId: string
  name: string
  type: EventType
  date: Timestamp
  planningStart?: Timestamp
  location?: string
  expectedAudience?: number
  responsible?: string
  status: EventStatus
  team?: string[]
  description?: string
  createdAt: Timestamp
  updatedAt: Timestamp
}

export interface ChecklistItem {
  id?: string
  userId: string
  eventId: string
  description: string
  responsible?: string
  dueDate?: Timestamp
  status: 'pendente' | 'em_andamento' | 'concluido'
  createdAt: Timestamp
}

export type PaymentMethod  = 'pix' | 'cartao_debito' | 'cartao_credito' | 'carne'
export type PaymentStatus  = 'pago' | 'pendente' | 'atrasado'
export type ParticipantStatus = 'aprovado' | 'pendente' | 'recusado'

export interface Installment {
  number: number
  dueDate: Timestamp
  amount: number
  paidAt?: Timestamp
  status: PaymentStatus
}

export interface RetreatParticipant {
  id?: string
  userId: string
  eventId: string
  name: string
  age: number
  phone?: string
  // Guardian (minors)
  guardianName?: string
  guardianPhone?: string
  // Financial
  totalAmount: number
  paymentMethod: PaymentMethod
  paymentStatus: PaymentStatus
  paidAt?: Timestamp
  installments?: Installment[]
  participantStatus: ParticipantStatus
  createdAt: Timestamp
  updatedAt: Timestamp
}

export interface Leader {
  id?: string
  userId: string
  name: string
  role?: string
  accessLevel: 'admin' | 'lider' | 'auxiliar'
  phone?: string
  linkedEvents?: string[]
  createdAt: Timestamp
}

export interface Idea {
  id?: string
  userId: string
  eventId?: string
  idea: string
  status: 'em_analise' | 'aprovada' | 'rejeitada'
  author?: string
  createdAt: Timestamp
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const now = () => Timestamp.now()

// Multi-tenancy: every collection is scoped to userId
// Path: /tenants/{userId}/{collection}
const tenantCol = (userId: string, col: string) =>
  collection(db, 'tenants', userId, col)

// ─── Events ──────────────────────────────────────────────────────────────────

export const eventsService = {
  async create(userId: string, data: Omit<Event, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) {
    return addDoc(tenantCol(userId, 'events'), {
      ...data, userId, createdAt: now(), updatedAt: now(),
    })
  },

  async update(userId: string, eventId: string, data: Partial<Event>) {
    return updateDoc(doc(db, 'tenants', userId, 'events', eventId), {
      ...data, updatedAt: now(),
    })
  },

  async delete(userId: string, eventId: string) {
    return deleteDoc(doc(db, 'tenants', userId, 'events', eventId))
  },

  subscribe(userId: string, callback: (events: Event[]) => void): Unsubscribe {
    const q = query(tenantCol(userId, 'events'), orderBy('date', 'asc'))
    return onSnapshot(q, snap => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as Event)))
    })
  },
}

// ─── Checklist ───────────────────────────────────────────────────────────────

export const checklistService = {
  async create(userId: string, data: Omit<ChecklistItem, 'id' | 'userId' | 'createdAt'>) {
    return addDoc(tenantCol(userId, 'checklist'), {
      ...data, userId, createdAt: now(),
    })
  },

  async update(userId: string, itemId: string, data: Partial<ChecklistItem>) {
    return updateDoc(doc(db, 'tenants', userId, 'checklist', itemId), data)
  },

  async delete(userId: string, itemId: string) {
    return deleteDoc(doc(db, 'tenants', userId, 'checklist', itemId))
  },

  subscribe(userId: string, eventId: string, callback: (items: ChecklistItem[]) => void): Unsubscribe {
    const q = query(
      tenantCol(userId, 'checklist'),
      where('eventId', '==', eventId),
      orderBy('createdAt', 'asc'),
    )
    return onSnapshot(q, snap => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as ChecklistItem)))
    })
  },
}

// ─── Retreat Participants ─────────────────────────────────────────────────────

export const retreatService = {
  async create(userId: string, data: Omit<RetreatParticipant, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) {
    return addDoc(tenantCol(userId, 'participants'), {
      ...data, userId, createdAt: now(), updatedAt: now(),
    })
  },

  async update(userId: string, participantId: string, data: Partial<RetreatParticipant>) {
    return updateDoc(doc(db, 'tenants', userId, 'participants', participantId), {
      ...data, updatedAt: now(),
    })
  },

  async delete(userId: string, participantId: string) {
    return deleteDoc(doc(db, 'tenants', userId, 'participants', participantId))
  },

  subscribe(userId: string, eventId: string, callback: (participants: RetreatParticipant[]) => void): Unsubscribe {
    const q = query(
      tenantCol(userId, 'participants'),
      where('eventId', '==', eventId),
      orderBy('createdAt', 'asc'),
    )
    return onSnapshot(q, snap => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as RetreatParticipant)))
    })
  },

  subscribeAll(userId: string, callback: (participants: RetreatParticipant[]) => void): Unsubscribe {
    const q = query(tenantCol(userId, 'participants'), orderBy('createdAt', 'desc'))
    return onSnapshot(q, snap => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as RetreatParticipant)))
    })
  },
}

// ─── Leaders ─────────────────────────────────────────────────────────────────

export const leadersService = {
  async create(userId: string, data: Omit<Leader, 'id' | 'userId' | 'createdAt'>) {
    return addDoc(tenantCol(userId, 'leaders'), { ...data, userId, createdAt: now() })
  },

  async update(userId: string, leaderId: string, data: Partial<Leader>) {
    return updateDoc(doc(db, 'tenants', userId, 'leaders', leaderId), data)
  },

  async delete(userId: string, leaderId: string) {
    return deleteDoc(doc(db, 'tenants', userId, 'leaders', leaderId))
  },

  subscribe(userId: string, callback: (leaders: Leader[]) => void): Unsubscribe {
    return onSnapshot(tenantCol(userId, 'leaders'), snap => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as Leader)))
    })
  },
}

// ─── Ideas ───────────────────────────────────────────────────────────────────

export const ideasService = {
  async create(userId: string, data: Omit<Idea, 'id' | 'userId' | 'createdAt'>) {
    return addDoc(tenantCol(userId, 'ideas'), { ...data, userId, createdAt: now() })
  },

  async update(userId: string, ideaId: string, data: Partial<Idea>) {
    return updateDoc(doc(db, 'tenants', userId, 'ideas', ideaId), data)
  },

  async delete(userId: string, ideaId: string) {
    return deleteDoc(doc(db, 'tenants', userId, 'ideas', ideaId))
  },

  subscribe(userId: string, callback: (ideas: Idea[]) => void): Unsubscribe {
    const q = query(tenantCol(userId, 'ideas'), orderBy('createdAt', 'desc'))
    return onSnapshot(q, snap => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as Idea)))
    })
  },
}
