// src/services/authService.ts
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  type User,
  type Unsubscribe,
} from 'firebase/auth'
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore'
import { auth, db } from './firebase'

export interface ChurchProfile {
  uid: string
  email: string
  churchName: string
  plan: 'free' | 'pro'
  createdAt: unknown
}

export const authService = {
  /** Register new church account */
  async register(email: string, password: string, churchName: string): Promise<User> {
    const cred = await createUserWithEmailAndPassword(auth, email, password)
    await updateProfile(cred.user, { displayName: churchName })

    // Create church profile document in Firestore
    await setDoc(doc(db, 'tenants', cred.user.uid), {
      uid:        cred.user.uid,
      email,
      churchName,
      plan:       'free',
      createdAt:  serverTimestamp(),
    } satisfies Omit<ChurchProfile, 'createdAt'> & { createdAt: unknown })

    return cred.user
  },

  async login(email: string, password: string): Promise<User> {
    const cred = await signInWithEmailAndPassword(auth, email, password)
    return cred.user
  },

  async logout(): Promise<void> {
    return signOut(auth)
  },

  async resetPassword(email: string): Promise<void> {
    return sendPasswordResetEmail(auth, email)
  },

  async getProfile(uid: string): Promise<ChurchProfile | null> {
    const snap = await getDoc(doc(db, 'tenants', uid))
    return snap.exists() ? (snap.data() as ChurchProfile) : null
  },

  onAuthChanged(callback: (user: User | null) => void): Unsubscribe {
    return onAuthStateChanged(auth, callback)
  },
}
