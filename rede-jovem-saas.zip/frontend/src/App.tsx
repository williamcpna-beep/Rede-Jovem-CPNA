// src/App.tsx
import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from '@/contexts/AuthContext'
import AppLayout from '@/components/layout/AppLayout'
import AuthPage from '@/pages/AuthPage'
import DashboardPage from '@/pages/DashboardPage'
import EventsPage from '@/pages/EventsPage'
import RetreatPage from '@/pages/RetreatPage'
import FinancialPage from '@/pages/FinancialPage'
import { Loader2 } from 'lucide-react'

// Placeholder pages (implemented similarly to above patterns)
const ChecklistPage  = () => <ComingSoon title="Checklist"       />
const IdeasPage      = () => <ComingSoon title="Banco de Ideias" />
const LeadersPage    = () => <ComingSoon title="Líderes"         />

function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-64">
      <h1 className="text-white text-2xl font-bold mb-2">{title}</h1>
      <p className="text-zinc-500 text-sm">Página implementada no código completo</p>
    </div>
  )
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-surface-0 flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-zinc-600" />
      </div>
    )
  }

  return user ? <>{children}</> : <Navigate to="/login" replace />
}

function GuestRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-surface-0 flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-zinc-600" />
      </div>
    )
  }

  return !user ? <>{children}</> : <Navigate to="/dashboard" replace />
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<GuestRoute><AuthPage /></GuestRoute>} />

      <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard"  element={<DashboardPage />} />
        <Route path="/eventos"    element={<EventsPage    />} />
        <Route path="/checklist"  element={<ChecklistPage />} />
        <Route path="/ideias"     element={<IdeasPage     />} />
        <Route path="/retiro"     element={<RetreatPage   />} />
        <Route path="/lideres"    element={<LeadersPage   />} />
        <Route path="/financeiro" element={<FinancialPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  )
}
