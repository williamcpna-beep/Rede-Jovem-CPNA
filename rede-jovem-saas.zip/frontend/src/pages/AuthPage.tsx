// src/pages/AuthPage.tsx
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import { Eye, EyeOff, Loader2 } from 'lucide-react'

type Mode = 'login' | 'register' | 'reset'

export default function AuthPage() {
  const [mode, setMode]             = useState<Mode>('login')
  const [email, setEmail]           = useState('')
  const [password, setPassword]     = useState('')
  const [churchName, setChurchName] = useState('')
  const [showPass, setShowPass]     = useState(false)
  const [loading, setLoading]       = useState(false)
  const [error, setError]           = useState('')
  const [success, setSuccess]       = useState('')

  const { login, register, resetPassword } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess('')
    setLoading(true)

    try {
      if (mode === 'login') {
        await login(email, password)
        navigate('/dashboard')
      } else if (mode === 'register') {
        await register(email, password, churchName)
        navigate('/dashboard')
      } else {
        await resetPassword(email)
        setSuccess('E-mail de recuperação enviado! Verifique sua caixa de entrada.')
      }
    } catch (err: any) {
      const msgs: Record<string, string> = {
        'auth/invalid-credential':      'E-mail ou senha incorretos.',
        'auth/email-already-in-use':    'Este e-mail já está cadastrado.',
        'auth/weak-password':           'A senha precisa ter pelo menos 6 caracteres.',
        'auth/too-many-requests':       'Muitas tentativas. Aguarde alguns minutos.',
      }
      setError(msgs[err.code] ?? 'Algo deu errado. Tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-surface-0 flex items-center justify-center p-4">
      {/* Background glow */}
      <div className="fixed inset-0 bg-gradient-glow pointer-events-none" />

      <div className="w-full max-w-md relative z-10 animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="flex justify-center mb-6">
            <img
              src="/logo-rede-jovem.png"
              alt="CPN Rede Jovem"
              className="h-14 w-auto object-contain"
            />
          </div>
          <h1 className="text-white text-2xl font-bold mt-2">
            {mode === 'login'    && 'Bem-vindo de volta'}
            {mode === 'register' && 'Criar sua conta'}
            {mode === 'reset'    && 'Recuperar senha'}
          </h1>
          <p className="text-zinc-500 text-sm mt-1">
            {mode === 'login'    && 'Acesse o painel da sua igreja'}
            {mode === 'register' && 'Configure sua igreja em minutos'}
            {mode === 'reset'    && 'Enviaremos um link de recuperação'}
          </p>
        </div>

        {/* Card */}
        <div className="bg-surface-1 border border-surface-4 rounded-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="text-sm text-zinc-400 mb-1.5 block">
                  Nome da Igreja
                </label>
                <input
                  type="text"
                  value={churchName}
                  onChange={e => setChurchName(e.target.value)}
                  placeholder="Ex: Igreja CPN Itaguaí"
                  required
                  className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                />
              </div>
            )}

            <div>
              <label className="text-sm text-zinc-400 mb-1.5 block">E-mail</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="pastor@suaigreja.com"
                required
                className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
              />
            </div>

            {mode !== 'reset' && (
              <div>
                <label className="text-sm text-zinc-400 mb-1.5 block">Senha</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    required
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 pr-12 text-white placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition-colors"
                  >
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-950/50 border border-red-900 rounded-xl px-4 py-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            {success && (
              <div className="bg-green-950/50 border border-green-900 rounded-xl px-4 py-3 text-green-400 text-sm">
                {success}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-brand text-white font-semibold rounded-xl py-3.5 hover:opacity-90 active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={16} className="animate-spin" />}
              {mode === 'login'    && 'Entrar'}
              {mode === 'register' && 'Criar conta'}
              {mode === 'reset'    && 'Enviar e-mail'}
            </button>
          </form>

          {/* Switchers */}
          <div className="mt-6 text-center space-y-2">
            {mode === 'login' && (
              <>
                <button onClick={() => setMode('reset')} className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors block w-full">
                  Esqueci minha senha
                </button>
                <p className="text-sm text-zinc-500">
                  Ainda não tem conta?{' '}
                  <button onClick={() => setMode('register')} className="text-brand-blue hover:underline font-medium">
                    Criar agora
                  </button>
                </p>
              </>
            )}
            {mode === 'register' && (
              <p className="text-sm text-zinc-500">
                Já tem conta?{' '}
                <button onClick={() => setMode('login')} className="text-brand-blue hover:underline font-medium">
                  Entrar
                </button>
              </p>
            )}
            {mode === 'reset' && (
              <button onClick={() => setMode('login')} className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors">
                ← Voltar ao login
              </button>
            )}
          </div>
        </div>

        <p className="text-center text-xs text-zinc-700 mt-6">
          © 2024 CPN Rede Jovem · Todos os direitos reservados
        </p>
      </div>
    </div>
  )
}
