// src/pages/FinancialPage.tsx
import React, { useState, useMemo } from 'react'
import { useAllParticipants } from '@/hooks/useFirestore'
import { useEvents } from '@/hooks/useFirestore'
import { retreatService, type RetreatParticipant, type PaymentStatus, type Installment } from '@/services/firestoreService'
import { useAuth } from '@/contexts/AuthContext'
import { Timestamp } from 'firebase/firestore'
import { format, isBefore } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import {
  DollarSign, TrendingUp, AlertTriangle, CheckCircle2,
  ChevronDown, X, Loader2, Receipt, CreditCard,
} from 'lucide-react'
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend,
} from 'recharts'
import clsx from 'clsx'

const fmtBRL = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const fmtDate = (ts?: Timestamp) => ts ? format(ts.toDate(), 'dd/MM/yyyy', { locale: ptBR }) : '—'

const STATUS_COLORS = {
  pago:     '#22C55E',
  pendente: '#F59E0B',
  atrasado: '#EF4444',
}

const STATUS_LABELS: Record<PaymentStatus, string> = {
  pago:     'Pago',
  pendente: 'Pendente',
  atrasado: 'Atrasado',
}

export default function FinancialPage() {
  const { user }          = useAuth()
  const { participants }  = useAllParticipants()
  const { events }        = useEvents()
  const [selectedEvent,   setSelectedEvent]  = useState<string>('all')
  const [carnêModal,      setCarnêModal]     = useState<RetreatParticipant | null>(null)
  const [updating,        setUpdating]       = useState<string | null>(null)

  const filtered = useMemo(() =>
    selectedEvent === 'all'
      ? participants
      : participants.filter(p => p.eventId === selectedEvent),
  [participants, selectedEvent])

  const metrics = useMemo(() => {
    const total    = filtered.reduce((s, p) => s + p.totalAmount, 0)
    const paid     = filtered.filter(p => p.paymentStatus === 'pago').reduce((s, p) => s + p.totalAmount, 0)
    const pending  = filtered.filter(p => p.paymentStatus === 'pendente').reduce((s, p) => s + p.totalAmount, 0)
    const overdue  = filtered.filter(p => p.paymentStatus === 'atrasado').reduce((s, p) => s + p.totalAmount, 0)
    const byStatus = [
      { name: 'Pago',     value: paid,    color: STATUS_COLORS.pago    },
      { name: 'Pendente', value: pending, color: STATUS_COLORS.pendente },
      { name: 'Atrasado', value: overdue, color: STATUS_COLORS.atrasado },
    ].filter(s => s.value > 0)
    return { total, paid, pending, overdue, byStatus }
  }, [filtered])

  const markInstallmentPaid = async (participant: RetreatParticipant, installmentNum: number) => {
    if (!user || !participant.id) return
    setUpdating(`${participant.id}-${installmentNum}`)
    const updated = (participant.installments ?? []).map(inst =>
      inst.number === installmentNum
        ? { ...inst, status: 'pago' as PaymentStatus, paidAt: Timestamp.now() }
        : inst
    )
    const allPaid = updated.every(i => i.status === 'pago')
    await retreatService.update(user.uid, participant.id, {
      installments:  updated,
      paymentStatus: allPaid ? 'pago' : 'pendente',
    })
    setCarnêModal(prev => prev ? { ...prev, installments: updated, paymentStatus: allPaid ? 'pago' : 'pendente' } : null)
    setUpdating(null)
  }

  const retiroEvents = events.filter(e => e.type === 'retiro')

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-white text-2xl font-bold">Painel Financeiro</h1>
        <p className="text-zinc-500 text-sm mt-0.5">Acompanhe toda a arrecadação dos eventos</p>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-3">
        <div className="relative">
          <select
            value={selectedEvent}
            onChange={e => setSelectedEvent(e.target.value)}
            className="appearance-none bg-surface-1 border border-surface-4 rounded-xl px-4 py-2.5 pr-8 text-sm text-white focus:outline-none focus:border-brand-blue transition-colors"
          >
            <option value="all">Todos os eventos</option>
            {events.map(ev => <option key={ev.id} value={ev.id}>{ev.name}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total',    value: fmtBRL(metrics.total),   color: 'text-zinc-300',   icon: DollarSign   },
          { label: 'Pago',     value: fmtBRL(metrics.paid),    color: 'text-green-400',  icon: CheckCircle2 },
          { label: 'Pendente', value: fmtBRL(metrics.pending), color: 'text-yellow-400', icon: TrendingUp   },
          { label: 'Atrasado', value: fmtBRL(metrics.overdue), color: 'text-red-400',    icon: AlertTriangle},
        ].map(({ label, value, color, icon: Icon }) => (
          <div key={label} className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Icon size={15} className={color} />
              <p className="text-zinc-500 text-sm">{label}</p>
            </div>
            <p className={clsx('text-xl font-bold', color)}>{value}</p>
          </div>
        ))}
      </div>

      {/* Chart + table */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Pie chart */}
        <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-4">Distribuição</h2>
          {metrics.byStatus.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={metrics.byStatus} cx="50%" cy="50%" innerRadius={55} outerRadius={80} dataKey="value" paddingAngle={4}>
                  {metrics.byStatus.map(s => <Cell key={s.name} fill={s.color} />)}
                </Pie>
                <Tooltip
                  formatter={(v: number) => [fmtBRL(v), '']}
                  contentStyle={{ background: '#1A1A1A', border: '1px solid #2E2E2E', borderRadius: 12, color: '#fff' }}
                />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, color: '#71717a' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-zinc-600 text-sm">
              Sem dados ainda
            </div>
          )}
        </div>

        {/* Participants table */}
        <div className="lg:col-span-2 bg-surface-1 border border-surface-4 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-surface-3">
            <h2 className="text-white font-semibold">Participantes</h2>
          </div>
          <div className="overflow-x-auto">
            {filtered.length === 0 ? (
              <div className="p-10 text-center text-zinc-600 text-sm">
                Nenhum participante encontrado
              </div>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="border-b border-surface-3">
                    {['Nome', 'Evento', 'Total', 'Pago', 'Em Aberto', 'Status', ''].map(h => (
                      <th key={h} className="text-left text-xs text-zinc-500 uppercase tracking-wider px-4 py-3 font-medium">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p, i) => {
                    const eventName = events.find(e => e.id === p.eventId)?.name ?? '—'
                    const paidAmt  = p.paymentStatus === 'pago' ? p.totalAmount : 0
                    const openAmt  = p.totalAmount - paidAmt
                    return (
                      <tr
                        key={p.id}
                        className={clsx('border-b border-surface-3/50 hover:bg-surface-2/50 transition-colors', i === filtered.length - 1 && 'border-b-0')}
                      >
                        <td className="px-4 py-3.5">
                          <p className="text-white text-sm font-medium">{p.name}</p>
                          <p className="text-zinc-500 text-xs mt-0.5 capitalize">{p.paymentMethod.replace('_', ' ')}</p>
                        </td>
                        <td className="px-4 py-3.5 text-sm text-zinc-400 whitespace-nowrap">{eventName}</td>
                        <td className="px-4 py-3.5 text-sm text-white">{fmtBRL(p.totalAmount)}</td>
                        <td className="px-4 py-3.5 text-sm text-green-400">{fmtBRL(paidAmt)}</td>
                        <td className="px-4 py-3.5 text-sm text-yellow-400">{fmtBRL(openAmt)}</td>
                        <td className="px-4 py-3.5">
                          <span className={clsx(
                            'text-xs font-medium px-2.5 py-1 rounded-lg',
                            p.paymentStatus === 'pago'     && 'bg-green-950/50  text-green-400',
                            p.paymentStatus === 'pendente' && 'bg-yellow-950/50 text-yellow-400',
                            p.paymentStatus === 'atrasado' && 'bg-red-950/50    text-red-400',
                          )}>
                            {STATUS_LABELS[p.paymentStatus]}
                          </span>
                        </td>
                        <td className="px-4 py-3.5">
                          {p.paymentMethod === 'carne' && (
                            <button
                              onClick={() => setCarnêModal(p)}
                              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-surface-3 text-zinc-500 hover:text-brand-blue transition-colors"
                              title="Ver carnê"
                            >
                              <Receipt size={14} />
                            </button>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {/* Carnê modal */}
      {carnêModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-surface-1 border border-surface-4 rounded-2xl w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between p-5 border-b border-surface-3">
              <div>
                <h2 className="text-white font-semibold">Carnê de Parcelas</h2>
                <p className="text-zinc-500 text-sm mt-0.5">{carnêModal.name}</p>
              </div>
              <button onClick={() => setCarnêModal(null)} className="text-zinc-500 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <div className="p-5 space-y-2">
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-surface-2 rounded-xl p-3 text-center">
                  <p className="text-zinc-500 text-xs mb-1">Total</p>
                  <p className="text-white text-sm font-bold">{fmtBRL(carnêModal.totalAmount)}</p>
                </div>
                <div className="bg-surface-2 rounded-xl p-3 text-center">
                  <p className="text-zinc-500 text-xs mb-1">Parcelas</p>
                  <p className="text-white text-sm font-bold">{carnêModal.installments?.length ?? 0}×</p>
                </div>
                <div className="bg-surface-2 rounded-xl p-3 text-center">
                  <p className="text-zinc-500 text-xs mb-1">Status</p>
                  <p className={clsx(
                    'text-sm font-bold',
                    carnêModal.paymentStatus === 'pago' ? 'text-green-400' : 'text-yellow-400',
                  )}>
                    {STATUS_LABELS[carnêModal.paymentStatus]}
                  </p>
                </div>
              </div>

              {(carnêModal.installments ?? []).map(inst => (
                <div
                  key={inst.number}
                  className="flex items-center gap-3 bg-surface-2 rounded-xl p-3.5"
                >
                  <div className={clsx(
                    'w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0',
                    inst.status === 'pago' ? 'bg-green-950 text-green-400' : 'bg-surface-3 text-zinc-400',
                  )}>
                    {inst.number}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm">{fmtBRL(inst.amount)}</p>
                    <p className="text-zinc-500 text-xs">Venc: {fmtDate(inst.dueDate)}</p>
                  </div>
                  {inst.status === 'pago' ? (
                    <span className="text-green-400 text-xs flex items-center gap-1">
                      <CheckCircle2 size={13} /> Pago
                    </span>
                  ) : (
                    <button
                      onClick={() => markInstallmentPaid(carnêModal, inst.number)}
                      disabled={!!updating}
                      className="text-xs bg-green-950/50 text-green-400 border border-green-900/50 px-3 py-1.5 rounded-lg hover:bg-green-950 transition-colors flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {updating === `${carnêModal.id}-${inst.number}` ? (
                        <Loader2 size={11} className="animate-spin" />
                      ) : (
                        <CreditCard size={11} />
                      )}
                      Marcar pago
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
