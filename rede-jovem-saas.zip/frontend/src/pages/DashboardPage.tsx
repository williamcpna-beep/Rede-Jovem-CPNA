// src/pages/DashboardPage.tsx
import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import { useEvents } from '@/hooks/useFirestore'
import { useAllParticipants } from '@/hooks/useFirestore'
import { format, isAfter, isBefore, addDays } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { Timestamp } from 'firebase/firestore'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
} from 'recharts'
import {
  Calendar, AlertTriangle, DollarSign, TrendingUp,
  CheckCircle2, Clock, XCircle, Plus, ArrowRight,
} from 'lucide-react'
import clsx from 'clsx'

const fmt = (ts: Timestamp) => format(ts.toDate(), 'dd/MM/yyyy', { locale: ptBR })

const getEventRisk = (event: { date: Timestamp; status: string }) => {
  if (event.status === 'concluido' || event.status === 'cancelado') return 'ok'
  const d = event.date.toDate()
  const now = new Date()
  if (isBefore(d, now)) return 'atrasado'
  if (isBefore(d, addDays(now, 7))) return 'atencao'
  return 'ok'
}

const STATUS_COLORS: Record<string, string> = {
  planejando:   '#0EA5E9',
  em_andamento: '#F59E0B',
  concluido:    '#22C55E',
  cancelado:    '#71717A',
}

function StatCard({
  icon: Icon, label, value, sub, color = 'blue',
}: {
  icon: React.ElementType
  label: string
  value: string | number
  sub?: string
  color?: 'blue' | 'yellow' | 'pink' | 'green' | 'red'
}) {
  const colorMap = {
    blue:   'text-brand-blue   bg-brand-blue/10',
    yellow: 'text-brand-yellow bg-brand-yellow/10',
    pink:   'text-brand-pink   bg-brand-pink/10',
    green:  'text-green-400    bg-green-400/10',
    red:    'text-red-400      bg-red-400/10',
  }
  return (
    <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5 hover:border-surface-5 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <p className="text-zinc-500 text-sm">{label}</p>
        <div className={clsx('w-9 h-9 rounded-xl flex items-center justify-center', colorMap[color])}>
          <Icon size={18} />
        </div>
      </div>
      <p className="text-white text-2xl font-bold">{value}</p>
      {sub && <p className="text-zinc-600 text-xs mt-1">{sub}</p>}
    </div>
  )
}

export default function DashboardPage() {
  const { profile } = useAuth()
  const { events, loading: evLoading } = useEvents()
  const { participants } = useAllParticipants()
  const navigate = useNavigate()

  const metrics = useMemo(() => {
    const riskEvents = events.filter(e => getEventRisk(e) === 'atrasado' || getEventRisk(e) === 'atencao')
    const totalCollected = participants.filter(p => p.paymentStatus === 'pago').reduce((s, p) => s + p.totalAmount, 0)
    const totalPending   = participants.filter(p => p.paymentStatus !== 'pago').reduce((s, p) => s + p.totalAmount, 0)

    const byStatus = Object.entries(
      events.reduce((acc, e) => ({ ...acc, [e.status]: (acc[e.status] ?? 0) + 1 }), {} as Record<string, number>)
    ).map(([name, qty]) => ({ name, qty }))

    return { riskEvents, totalCollected, totalPending, byStatus }
  }, [events, participants])

  const upcomingEvents = events
    .filter(e => e.status !== 'cancelado' && isAfter(e.date.toDate(), new Date()))
    .slice(0, 5)

  const formatCurrency = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite'

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-zinc-500 text-sm">{greeting} 👋</p>
          <h1 className="text-white text-2xl font-bold mt-0.5">
            {profile?.churchName ?? 'Minha Igreja'}
          </h1>
        </div>
        <button
          onClick={() => navigate('/eventos')}
          className="flex items-center gap-2 bg-gradient-brand text-white text-sm font-medium px-4 py-2.5 rounded-xl hover:opacity-90 active:scale-[0.98] transition-all"
        >
          <Plus size={16} />
          Novo Evento
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Calendar}
          label="Total de Eventos"
          value={events.length}
          sub={`${events.filter(e => e.status === 'em_andamento').length} em andamento`}
          color="blue"
        />
        <StatCard
          icon={AlertTriangle}
          label="Em Risco"
          value={metrics.riskEvents.length}
          sub="precisam de atenção"
          color={metrics.riskEvents.length > 0 ? 'red' : 'green'}
        />
        <StatCard
          icon={DollarSign}
          label="Arrecadado"
          value={formatCurrency(metrics.totalCollected)}
          sub="pagamentos confirmados"
          color="green"
        />
        <StatCard
          icon={TrendingUp}
          label="Pendente"
          value={formatCurrency(metrics.totalPending)}
          sub="aguardando pagamento"
          color="yellow"
        />
      </div>

      {/* Charts + upcoming */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Bar chart */}
        <div className="lg:col-span-2 bg-surface-1 border border-surface-4 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-white font-semibold">Status dos Eventos</h2>
          </div>
          {metrics.byStatus.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={metrics.byStatus} barSize={32}>
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#71717a', fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={v => ({ planejando: 'Planejando', em_andamento: 'Em andamento', concluido: 'Concluído', cancelado: 'Cancelado' }[v] ?? v)}
                />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ background: '#1A1A1A', border: '1px solid #2E2E2E', borderRadius: 12, color: '#fff' }}
                  cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                />
                <Bar dataKey="qty" radius={[6, 6, 0, 0]}>
                  {metrics.byStatus.map(entry => (
                    <Cell key={entry.name} fill={STATUS_COLORS[entry.name] ?? '#0EA5E9'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-zinc-600 text-sm">
              Nenhum evento cadastrado ainda
            </div>
          )}
        </div>

        {/* Upcoming events */}
        <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white font-semibold">Próximos Eventos</h2>
            <button
              onClick={() => navigate('/eventos')}
              className="text-brand-blue text-xs flex items-center gap-1 hover:gap-2 transition-all"
            >
              Ver todos <ArrowRight size={12} />
            </button>
          </div>
          <div className="space-y-3">
            {upcomingEvents.length === 0 && (
              <p className="text-zinc-600 text-sm text-center py-8">Nenhum evento futuro</p>
            )}
            {upcomingEvents.map(ev => {
              const risk = getEventRisk(ev)
              return (
                <div key={ev.id} className="flex items-start gap-3 p-3 bg-surface-2 rounded-xl">
                  <div className={clsx(
                    'w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0',
                    risk === 'atrasado' ? 'bg-red-400'   :
                    risk === 'atencao'  ? 'bg-yellow-400' : 'bg-green-400',
                  )} />
                  <div className="min-w-0">
                    <p className="text-white text-sm font-medium truncate">{ev.name}</p>
                    <p className="text-zinc-500 text-xs mt-0.5">{fmt(ev.date)}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Risk events alert */}
      {metrics.riskEvents.length > 0 && (
        <div className="bg-red-950/40 border border-red-900/50 rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle size={20} className="text-red-400" />
            <h2 className="text-red-300 font-semibold">Eventos que precisam de atenção</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {metrics.riskEvents.map(ev => (
              <div key={ev.id} className="flex items-center gap-3 bg-red-950/30 border border-red-900/30 rounded-xl p-3">
                {getEventRisk(ev) === 'atrasado'
                  ? <XCircle size={16} className="text-red-400 flex-shrink-0" />
                  : <Clock    size={16} className="text-yellow-400 flex-shrink-0" />
                }
                <div className="min-w-0">
                  <p className="text-white text-sm font-medium truncate">{ev.name}</p>
                  <p className="text-red-400/70 text-xs">{fmt(ev.date)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
