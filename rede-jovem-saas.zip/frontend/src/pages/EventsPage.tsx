// src/pages/EventsPage.tsx
import React, { useState, useMemo } from 'react'
import { useEvents } from '@/hooks/useFirestore'
import { Timestamp } from 'firebase/firestore'
import { format, isAfter, isBefore, addDays, differenceInDays } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import {
  Plus, Search, Calendar, MapPin, Users, Trash2,
  Edit2, X, ChevronDown, Loader2, Clock, CheckCircle, AlertTriangle,
} from 'lucide-react'
import clsx from 'clsx'
import type { Event, EventType, EventStatus } from '@/services/firestoreService'

const EVENT_TYPES: { value: EventType; label: string }[] = [
  { value: 'culto',        label: 'Culto'         },
  { value: 'retiro',       label: 'Retiro'        },
  { value: 'conferencia',  label: 'Conferência'   },
  { value: 'acao_social',  label: 'Ação Social'   },
  { value: 'reuniao',      label: 'Reunião'       },
  { value: 'outro',        label: 'Outro'         },
]

const STATUS_OPTIONS: { value: EventStatus; label: string }[] = [
  { value: 'planejando',   label: 'Planejando'    },
  { value: 'em_andamento', label: 'Em Andamento'  },
  { value: 'concluido',    label: 'Concluído'     },
  { value: 'cancelado',    label: 'Cancelado'     },
]

function getAutoStatus(event: Event): { label: string; color: string; icon: React.ElementType } {
  if (event.status === 'concluido')   return { label: 'Concluído',  color: 'text-green-400',  icon: CheckCircle    }
  if (event.status === 'cancelado')   return { label: 'Cancelado',  color: 'text-zinc-500',   icon: X              }
  const d = event.date.toDate()
  const now = new Date()
  if (isBefore(d, now))               return { label: 'Atrasado',   color: 'text-red-400',    icon: AlertTriangle  }
  if (isBefore(d, addDays(now, 7)))   return { label: 'Atenção',    color: 'text-yellow-400', icon: Clock          }
  return                                     { label: 'No Prazo',   color: 'text-blue-400',   icon: CheckCircle    }
}

function getProgress(event: Event): number {
  if (event.status === 'concluido') return 100
  if (event.status === 'cancelado') return 0
  if (!event.planningStart) return 20
  const start = event.planningStart.toDate()
  const end   = event.date.toDate()
  const now   = new Date()
  const total  = differenceInDays(end, start)
  const passed = differenceInDays(now, start)
  if (total <= 0) return 100
  return Math.min(100, Math.max(0, Math.round((passed / total) * 100)))
}

const EMPTY_FORM = {
  name: '', type: 'culto' as EventType, date: '', planningStart: '',
  location: '', expectedAudience: '', responsible: '',
  status: 'planejando' as EventStatus, description: '',
}

export default function EventsPage() {
  const { events, loading, create, update, remove } = useEvents()
  const [search,     setSearch]     = useState('')
  const [filterType, setFilterType] = useState<EventType | ''>('')
  const [modal,      setModal]      = useState(false)
  const [editing,    setEditing]    = useState<Event | null>(null)
  const [form,       setForm]       = useState(EMPTY_FORM)
  const [saving,     setSaving]     = useState(false)
  const [deleting,   setDeleting]   = useState<string | null>(null)

  const filtered = useMemo(() =>
    events.filter(e => {
      const matchSearch = e.name.toLowerCase().includes(search.toLowerCase())
      const matchType   = !filterType || e.type === filterType
      return matchSearch && matchType
    }),
  [events, search, filterType])

  const openCreate = () => {
    setEditing(null)
    setForm(EMPTY_FORM)
    setModal(true)
  }

  const openEdit = (ev: Event) => {
    setEditing(ev)
    setForm({
      name:            ev.name,
      type:            ev.type,
      date:            format(ev.date.toDate(), 'yyyy-MM-dd'),
      planningStart:   ev.planningStart ? format(ev.planningStart.toDate(), 'yyyy-MM-dd') : '',
      location:        ev.location ?? '',
      expectedAudience: String(ev.expectedAudience ?? ''),
      responsible:     ev.responsible ?? '',
      status:          ev.status,
      description:     ev.description ?? '',
    })
    setModal(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const data = {
        name:             form.name,
        type:             form.type,
        date:             Timestamp.fromDate(new Date(form.date + 'T12:00:00')),
        planningStart:    form.planningStart ? Timestamp.fromDate(new Date(form.planningStart + 'T12:00:00')) : undefined,
        location:         form.location || undefined,
        expectedAudience: form.expectedAudience ? Number(form.expectedAudience) : undefined,
        responsible:      form.responsible || undefined,
        status:           form.status,
        description:      form.description || undefined,
        churchId:         '',
      }
      if (editing?.id) {
        await update(editing.id, data)
      } else {
        await create(data)
      }
      setModal(false)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Excluir este evento?')) return
    setDeleting(id)
    try { await remove(id) } finally { setDeleting(null) }
  }

  const fmt = (ts: Timestamp) => format(ts.toDate(), 'dd/MM/yyyy', { locale: ptBR })

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Eventos</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{events.length} eventos cadastrados</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 bg-gradient-brand text-white text-sm font-medium px-4 py-2.5 rounded-xl hover:opacity-90 active:scale-[0.98] transition-all"
        >
          <Plus size={16} /> Novo Evento
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar eventos..."
            className="w-full bg-surface-1 border border-surface-4 rounded-xl pl-9 pr-4 py-2.5 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
          />
        </div>
        <div className="relative">
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value as EventType | '')}
            className="appearance-none bg-surface-1 border border-surface-4 rounded-xl px-4 py-2.5 pr-8 text-sm text-white focus:outline-none focus:border-brand-blue transition-colors"
          >
            <option value="">Todos os tipos</option>
            {EVENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 size={28} className="animate-spin text-zinc-600" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-surface-1 border border-surface-4 rounded-2xl p-12 text-center">
          <Calendar size={40} className="text-zinc-700 mx-auto mb-3" />
          <p className="text-zinc-500 text-sm">Nenhum evento encontrado</p>
          <button onClick={openCreate} className="mt-4 text-brand-blue text-sm hover:underline">
            Criar primeiro evento →
          </button>
        </div>
      ) : (
        <div className="bg-surface-1 border border-surface-4 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-surface-3">
                  {['Evento', 'Tipo', 'Data', 'Responsável', 'Status', 'Progresso', ''].map(h => (
                    <th key={h} className="text-left text-xs text-zinc-500 uppercase tracking-wider px-5 py-3.5 first:rounded-tl-2xl font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((ev, i) => {
                  const s = getAutoStatus(ev)
                  const p = getProgress(ev)
                  const StatusIcon = s.icon
                  return (
                    <tr
                      key={ev.id}
                      className={clsx('border-b border-surface-3/50 hover:bg-surface-2/50 transition-colors', i === filtered.length - 1 && 'border-b-0')}
                    >
                      <td className="px-5 py-4">
                        <p className="text-white font-medium text-sm">{ev.name}</p>
                        {ev.location && (
                          <p className="text-zinc-500 text-xs flex items-center gap-1 mt-0.5">
                            <MapPin size={10} /> {ev.location}
                          </p>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        <span className="text-xs bg-surface-3 text-zinc-400 px-2.5 py-1 rounded-lg capitalize">
                          {EVENT_TYPES.find(t => t.value === ev.type)?.label ?? ev.type}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-sm text-zinc-400 whitespace-nowrap">{fmt(ev.date)}</td>
                      <td className="px-5 py-4 text-sm text-zinc-400">{ev.responsible ?? '—'}</td>
                      <td className="px-5 py-4">
                        <span className={clsx('flex items-center gap-1.5 text-xs font-medium', s.color)}>
                          <StatusIcon size={13} /> {s.label}
                        </span>
                      </td>
                      <td className="px-5 py-4 w-32">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-surface-3 rounded-full h-1.5">
                            <div
                              className="h-1.5 rounded-full bg-gradient-brand transition-all"
                              style={{ width: `${p}%` }}
                            />
                          </div>
                          <span className="text-xs text-zinc-500 w-8 text-right">{p}%</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => openEdit(ev)}
                            className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-surface-3 text-zinc-500 hover:text-zinc-200 transition-colors"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button
                            onClick={() => handleDelete(ev.id!)}
                            disabled={deleting === ev.id}
                            className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-red-950/50 text-zinc-500 hover:text-red-400 transition-colors"
                          >
                            {deleting === ev.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-surface-1 border border-surface-4 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-slide-up">
            <div className="flex items-center justify-between p-6 border-b border-surface-3">
              <h2 className="text-white font-semibold">{editing ? 'Editar Evento' : 'Novo Evento'}</h2>
              <button onClick={() => setModal(false)} className="text-zinc-500 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="text-sm text-zinc-400 mb-1.5 block">Nome do Evento *</label>
                <input
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  required
                  className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                  placeholder="Ex: Culto de Jovens"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-zinc-400 mb-1.5 block">Tipo *</label>
                  <select
                    value={form.type}
                    onChange={e => setForm(f => ({ ...f, type: e.target.value as EventType }))}
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                  >
                    {EVENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm text-zinc-400 mb-1.5 block">Status</label>
                  <select
                    value={form.status}
                    onChange={e => setForm(f => ({ ...f, status: e.target.value as EventStatus }))}
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                  >
                    {STATUS_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-zinc-400 mb-1.5 block">Data do Evento *</label>
                  <input
                    type="date"
                    value={form.date}
                    onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                    required
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                  />
                </div>
                <div>
                  <label className="text-sm text-zinc-400 mb-1.5 block">Início do Planejamento</label>
                  <input
                    type="date"
                    value={form.planningStart}
                    onChange={e => setForm(f => ({ ...f, planningStart: e.target.value }))}
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-zinc-400 mb-1.5 block">Local</label>
                  <input
                    value={form.location}
                    onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                    placeholder="Ex: Sede Central"
                  />
                </div>
                <div>
                  <label className="text-sm text-zinc-400 mb-1.5 block">Público Esperado</label>
                  <input
                    type="number"
                    value={form.expectedAudience}
                    onChange={e => setForm(f => ({ ...f, expectedAudience: e.target.value }))}
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                    placeholder="100"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm text-zinc-400 mb-1.5 block">Responsável</label>
                <input
                  value={form.responsible}
                  onChange={e => setForm(f => ({ ...f, responsible: e.target.value }))}
                  className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                  placeholder="Nome do responsável"
                />
              </div>

              <div>
                <label className="text-sm text-zinc-400 mb-1.5 block">Descrição / Objetivo</label>
                <textarea
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  rows={3}
                  className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors resize-none"
                  placeholder="Descreva o objetivo do evento..."
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModal(false)}
                  className="flex-1 bg-surface-2 border border-surface-5 text-zinc-400 text-sm rounded-xl py-3 hover:text-white transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 bg-gradient-brand text-white text-sm font-medium rounded-xl py-3 hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {saving && <Loader2 size={14} className="animate-spin" />}
                  {editing ? 'Salvar Alterações' : 'Criar Evento'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
