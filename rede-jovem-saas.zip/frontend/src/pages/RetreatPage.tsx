// src/pages/RetreatPage.tsx
import React, { useState } from 'react'
import { useEvents, useRetreat } from '@/hooks/useFirestore'
import { Timestamp } from 'firebase/firestore'
import { format, addMonths } from 'date-fns'
import {
  Tent, Plus, ChevronDown, X, Loader2, Users, DollarSign,
  AlertTriangle, CheckCircle2, Trash2,
} from 'lucide-react'
import clsx from 'clsx'
import type { PaymentMethod, PaymentStatus, ParticipantStatus } from '@/services/firestoreService'

const fmtBRL  = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

const PAYMENT_METHODS = [
  { value: 'pix',            label: 'Pix'                },
  { value: 'cartao_debito',  label: 'Cartão de Débito'   },
  { value: 'cartao_credito', label: 'Cartão de Crédito'  },
  { value: 'carne',          label: 'Carnê'              },
]

const EMPTY_FORM = {
  name: '', age: '', phone: '',
  guardianName: '', guardianPhone: '',
  totalAmount: '', paymentMethod: 'pix' as PaymentMethod,
  paymentStatus: 'pendente' as PaymentStatus,
  participantStatus: 'pendente' as ParticipantStatus,
  installmentCount: 2, firstInstallmentDate: '',
}

export default function RetreatPage() {
  const { events }                                 = useEvents()
  const [selectedEventId, setSelectedEventId]      = useState<string>('')
  const { participants, loading, create, remove, summary } = useRetreat(selectedEventId)
  const [modal,  setModal]  = useState(false)
  const [form,   setForm]   = useState(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [tab,    setTab]    = useState<'all' | 'overdue'>('all')

  const retiroEvents = events.filter(e => e.type === 'retiro')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedEventId) return
    setSaving(true)
    try {
      const isCarne = form.paymentMethod === 'carne'
      const totalAmount = Number(form.totalAmount)
      let installments = undefined

      if (isCarne && form.firstInstallmentDate) {
        const amtPerInst  = totalAmount / form.installmentCount
        const baseDate    = new Date(form.firstInstallmentDate + 'T12:00:00')
        installments = Array.from({ length: form.installmentCount }, (_, i) => ({
          number:  i + 1,
          dueDate: Timestamp.fromDate(addMonths(baseDate, i)),
          amount:  amtPerInst,
          status:  'pendente' as PaymentStatus,
        }))
      }

      await create({
        eventId:           selectedEventId,
        name:              form.name,
        age:               Number(form.age),
        phone:             form.phone || undefined,
        guardianName:      form.guardianName || undefined,
        guardianPhone:     form.guardianPhone || undefined,
        totalAmount,
        paymentMethod:     form.paymentMethod,
        paymentStatus:     form.paymentStatus,
        participantStatus: form.participantStatus,
        installments,
        churchId:          '',
      })
      setModal(false)
      setForm(EMPTY_FORM)
    } finally {
      setSaving(false)
    }
  }

  const visibleParticipants = tab === 'overdue'
    ? participants.filter(p => p.paymentStatus === 'atrasado')
    : participants

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Módulo de Retiro</h1>
          <p className="text-zinc-500 text-sm mt-0.5">Gestão de participantes e finanças</p>
        </div>
        <button
          onClick={() => setModal(true)}
          disabled={!selectedEventId}
          className="flex items-center gap-2 bg-gradient-brand text-white text-sm font-medium px-4 py-2.5 rounded-xl hover:opacity-90 active:scale-[0.98] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Plus size={16} /> Inscrever
        </button>
      </div>

      {/* Event selector */}
      <div className="relative w-72">
        <select
          value={selectedEventId}
          onChange={e => setSelectedEventId(e.target.value)}
          className="appearance-none w-full bg-surface-1 border border-surface-4 rounded-xl px-4 py-2.5 pr-8 text-sm text-white focus:outline-none focus:border-brand-blue transition-colors"
        >
          <option value="">Selecione o retiro...</option>
          {retiroEvents.map(ev => <option key={ev.id} value={ev.id}>{ev.name}</option>)}
        </select>
        <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
      </div>

      {selectedEventId && (
        <>
          {/* Summary */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <Users size={15} className="text-brand-blue" />
                <p className="text-zinc-500 text-sm">Participantes</p>
              </div>
              <p className="text-white text-2xl font-bold">{summary.count}</p>
              <p className="text-zinc-600 text-xs mt-0.5">{summary.approved} aprovados</p>
            </div>
            <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign size={15} className="text-green-400" />
                <p className="text-zinc-500 text-sm">Arrecadado</p>
              </div>
              <p className="text-green-400 text-2xl font-bold">{fmtBRL(summary.paid)}</p>
            </div>
            <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle size={15} className="text-yellow-400" />
                <p className="text-zinc-500 text-sm">Pendente</p>
              </div>
              <p className="text-yellow-400 text-2xl font-bold">{fmtBRL(summary.pending)}</p>
            </div>
            <div className="bg-surface-1 border border-surface-4 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle size={15} className="text-red-400" />
                <p className="text-zinc-500 text-sm">Inadimplente</p>
              </div>
              <p className="text-red-400 text-2xl font-bold">{fmtBRL(summary.overdue)}</p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-surface-1 border border-surface-4 rounded-xl w-fit">
            {([['all', 'Todos'], ['overdue', 'Inadimplentes']] as const).map(([val, label]) => (
              <button
                key={val}
                onClick={() => setTab(val)}
                className={clsx(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  tab === val ? 'bg-surface-3 text-white' : 'text-zinc-500 hover:text-zinc-300',
                )}
              >
                {label}
                {val === 'overdue' && summary.overdue > 0 && (
                  <span className="ml-1.5 text-xs bg-red-950 text-red-400 px-1.5 py-0.5 rounded-md">
                    {participants.filter(p => p.paymentStatus === 'atrasado').length}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Table */}
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 size={24} className="animate-spin text-zinc-600" />
            </div>
          ) : (
            <div className="bg-surface-1 border border-surface-4 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                {visibleParticipants.length === 0 ? (
                  <div className="p-10 text-center">
                    <Tent size={36} className="text-zinc-700 mx-auto mb-3" />
                    <p className="text-zinc-500 text-sm">Nenhum participante cadastrado</p>
                  </div>
                ) : (
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-surface-3">
                        {['Nome', 'Idade', 'Telefone', 'Pagamento', 'Total', 'Pago', 'Em Aberto', 'Status', ''].map(h => (
                          <th key={h} className="text-left text-xs text-zinc-500 uppercase tracking-wider px-4 py-3 font-medium">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {visibleParticipants.map((p, i) => {
                        const paidAmt = p.paymentStatus === 'pago' ? p.totalAmount : 0
                        const openAmt = p.totalAmount - paidAmt
                        return (
                          <tr
                            key={p.id}
                            className={clsx('border-b border-surface-3/50 hover:bg-surface-2/50 transition-colors', i === visibleParticipants.length - 1 && 'border-b-0')}
                          >
                            <td className="px-4 py-3.5">
                              <p className="text-white text-sm font-medium">{p.name}</p>
                              {p.guardianName && <p className="text-zinc-500 text-xs">Resp: {p.guardianName}</p>}
                            </td>
                            <td className="px-4 py-3.5 text-sm text-zinc-400">{p.age}</td>
                            <td className="px-4 py-3.5 text-sm text-zinc-400">{p.phone ?? '—'}</td>
                            <td className="px-4 py-3.5">
                              <span className="text-xs bg-surface-3 text-zinc-400 px-2 py-1 rounded-lg capitalize">
                                {PAYMENT_METHODS.find(m => m.value === p.paymentMethod)?.label ?? p.paymentMethod}
                              </span>
                            </td>
                            <td className="px-4 py-3.5 text-sm text-white">{fmtBRL(p.totalAmount)}</td>
                            <td className="px-4 py-3.5 text-sm text-green-400">{fmtBRL(paidAmt)}</td>
                            <td className="px-4 py-3.5 text-sm text-yellow-400">{fmtBRL(openAmt)}</td>
                            <td className="px-4 py-3.5">
                              <span className={clsx(
                                'text-xs font-medium px-2.5 py-1 rounded-lg',
                                p.paymentStatus === 'pago'     && 'bg-green-950/50  text-green-400',
                                p.paymentStatus === 'pendente' && 'bg-yellow-950/50 text-yellow-400',
                                p.paymentStatus === 'atrasado' && 'bg-red-950/50    text-red-400',
                              )}>
                                {{ pago: 'Pago', pendente: 'Pendente', atrasado: 'Atrasado' }[p.paymentStatus]}
                              </span>
                            </td>
                            <td className="px-4 py-3.5">
                              <button
                                onClick={() => { if (confirm('Remover participante?')) remove(p.id!) }}
                                className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-red-950/50 text-zinc-500 hover:text-red-400 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* Registration Modal */}
      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-surface-1 border border-surface-4 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-slide-up">
            <div className="flex items-center justify-between p-6 border-b border-surface-3">
              <h2 className="text-white font-semibold">Inscrição de Retirante</h2>
              <button onClick={() => setModal(false)} className="text-zinc-500 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              {/* Personal */}
              <div>
                <h3 className="text-zinc-400 text-xs uppercase tracking-wider mb-3">Dados Pessoais</h3>
                <div className="space-y-3">
                  <input
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    required
                    placeholder="Nome Completo *"
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="number"
                      value={form.age}
                      onChange={e => setForm(f => ({ ...f, age: e.target.value }))}
                      required
                      placeholder="Idade *"
                      className="bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                    />
                    <input
                      value={form.phone}
                      onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                      placeholder="Telefone"
                      className="bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Guardian (show if minor) */}
              {Number(form.age) > 0 && Number(form.age) < 18 && (
                <div>
                  <h3 className="text-zinc-400 text-xs uppercase tracking-wider mb-3">Responsável (Menor de Idade)</h3>
                  <div className="space-y-3">
                    <input
                      value={form.guardianName}
                      onChange={e => setForm(f => ({ ...f, guardianName: e.target.value }))}
                      placeholder="Nome do Responsável"
                      className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                    />
                    <input
                      value={form.guardianPhone}
                      onChange={e => setForm(f => ({ ...f, guardianPhone: e.target.value }))}
                      placeholder="Contato do Responsável"
                      className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                    />
                  </div>
                </div>
              )}

              {/* Financial */}
              <div>
                <h3 className="text-zinc-400 text-xs uppercase tracking-wider mb-3">Ficha Financeira</h3>
                <div className="space-y-3">
                  <input
                    type="number"
                    value={form.totalAmount}
                    onChange={e => setForm(f => ({ ...f, totalAmount: e.target.value }))}
                    required
                    step="0.01"
                    placeholder="Valor Total (R$)"
                    className="w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-brand-blue transition-colors"
                  />

                  <div className="grid grid-cols-2 gap-3">
                    <div className="relative">
                      <select
                        value={form.paymentMethod}
                        onChange={e => setForm(f => ({ ...f, paymentMethod: e.target.value as PaymentMethod }))}
                        className="appearance-none w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 pr-7 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                      >
                        {PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                      </select>
                      <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
                    </div>
                    <div className="relative">
                      <select
                        value={form.paymentStatus}
                        onChange={e => setForm(f => ({ ...f, paymentStatus: e.target.value as PaymentStatus }))}
                        className="appearance-none w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 pr-7 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                      >
                        <option value="pago">Pago</option>
                        <option value="pendente">Pendente</option>
                        <option value="atrasado">Atrasado</option>
                      </select>
                      <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
                    </div>
                  </div>

                  {/* Carnê fields */}
                  {form.paymentMethod === 'carne' && (
                    <div className="grid grid-cols-2 gap-3 p-4 bg-surface-2 rounded-xl border border-surface-5">
                      <div>
                        <label className="text-zinc-400 text-xs mb-1.5 block">Nº de Parcelas</label>
                        <input
                          type="number"
                          value={form.installmentCount}
                          onChange={e => setForm(f => ({ ...f, installmentCount: Number(e.target.value) }))}
                          min={2}
                          max={24}
                          className="w-full bg-surface-1 border border-surface-4 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                        />
                      </div>
                      <div>
                        <label className="text-zinc-400 text-xs mb-1.5 block">Data da 1ª Parcela</label>
                        <input
                          type="date"
                          value={form.firstInstallmentDate}
                          onChange={e => setForm(f => ({ ...f, firstInstallmentDate: e.target.value }))}
                          className="w-full bg-surface-1 border border-surface-4 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                        />
                      </div>
                      {form.totalAmount && form.installmentCount > 0 && (
                        <div className="col-span-2 flex items-center justify-between text-sm">
                          <span className="text-zinc-500">Valor por parcela:</span>
                          <span className="text-white font-medium">
                            {fmtBRL(Number(form.totalAmount) / form.installmentCount)}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="relative">
                    <select
                      value={form.participantStatus}
                      onChange={e => setForm(f => ({ ...f, participantStatus: e.target.value as ParticipantStatus }))}
                      className="appearance-none w-full bg-surface-2 border border-surface-5 rounded-xl px-4 py-3 pr-7 text-white text-sm focus:outline-none focus:border-brand-blue transition-colors"
                    >
                      <option value="aprovado">Aprovado</option>
                      <option value="pendente">Pendente</option>
                      <option value="recusado">Recusado</option>
                    </select>
                    <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModal(false)}
                  className="flex-1 bg-surface-2 border border-surface-5 text-zinc-400 text-sm rounded-xl py-3 hover:text-white transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 bg-gradient-brand text-white text-sm font-medium rounded-xl py-3 hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {saving && <Loader2 size={14} className="animate-spin" />}
                  Salvar Inscrição
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
