// src/components/layout/AppLayout.tsx
import React, { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import {
  LayoutDashboard, Calendar, CheckSquare, Lightbulb,
  Tent, Users, DollarSign, LogOut, Menu,
  Bell,
} from 'lucide-react'
import clsx from 'clsx'

const NAV_ITEMS = [
  { to: '/dashboard',   icon: LayoutDashboard, label: 'Dashboard'    },
  { to: '/eventos',     icon: Calendar,        label: 'Eventos'       },
  { to: '/checklist',   icon: CheckSquare,     label: 'Checklist'     },
  { to: '/ideias',      icon: Lightbulb,       label: 'Banco de Ideias'},
  { to: '/retiro',      icon: Tent,            label: 'Retiro'        },
  { to: '/lideres',     icon: Users,           label: 'Líderes'       },
  { to: '/financeiro',  icon: DollarSign,      label: 'Financeiro'    },
]

export default function AppLayout() {
  const { profile, logout } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  const initials = profile?.churchName
    ? profile.churchName.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
    : 'RJ'

  return (
    <div className="flex min-h-screen bg-surface-0 text-white">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={clsx(
          'fixed top-0 left-0 h-full w-64 bg-surface-1 border-r border-surface-3 z-50',
          'flex flex-col transition-transform duration-300',
          'md:translate-x-0',
          mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0',
        )}
      >
        {/* Logo */}
        <div className="px-5 py-4 border-b border-surface-3">
          <img
            src="/logo-rede-jovem.png"
            alt="CPN Rede Jovem"
            className="h-10 w-auto object-contain"
          />
        </div>

        {/* Church name */}
        <div className="px-4 py-3 border-b border-surface-3">
          <div className="flex items-center gap-2.5 bg-surface-2 rounded-xl px-3 py-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-brand flex items-center justify-center text-[11px] font-bold flex-shrink-0">
              {initials}
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs font-medium truncate">{profile?.churchName ?? 'Minha Igreja'}</p>
              <p className="text-zinc-500 text-[10px] truncate">{profile?.plan === 'pro' ? '✦ Pro' : 'Plano Gratuito'}</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 overflow-y-auto">
          <p className="text-[10px] text-zinc-600 uppercase tracking-widest px-3 mb-2">Menu</p>
          {NAV_ITEMS.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) => clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl mb-0.5 text-sm transition-all',
                isActive
                  ? 'bg-surface-3 text-white font-medium'
                  : 'text-zinc-500 hover:text-zinc-200 hover:bg-surface-2',
              )}
            >
              {({ isActive }) => (
                <>
                  <Icon size={17} className={isActive ? 'text-brand-blue' : ''} />
                  {label}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-surface-3">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 text-zinc-500 hover:text-red-400 transition-colors text-sm w-full px-3 py-2 rounded-xl hover:bg-red-950/30"
          >
            <LogOut size={16} />
            Sair
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col md:ml-64 min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-surface-0/80 backdrop-blur border-b border-surface-3 px-4 md:px-6 py-3 flex items-center justify-between">
          <button
            className="md:hidden text-zinc-400 hover:text-white transition-colors"
            onClick={() => setMobileOpen(true)}
          >
            <Menu size={22} />
          </button>

          <div className="flex items-center gap-3 ml-auto">
            <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-surface-2 text-zinc-500 hover:text-zinc-300 transition-colors relative">
              <Bell size={16} />
              <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-brand-blue rounded-full" />
            </button>
            <div className="w-7 h-7 rounded-lg bg-gradient-brand flex items-center justify-center text-[11px] font-bold">
              {initials}
            </div>
          </div>
        </header>

        {/* Page */}
        <main className="flex-1 p-4 md:p-6 animate-fade-in">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
