// src/hooks/useFirestore.ts
import { useEffect, useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import {
  eventsService, checklistService, retreatService,
  leadersService, ideasService,
  type Event, type ChecklistItem, type RetreatParticipant,
  type Leader, type Idea,
} from '@/services/firestoreService'

// ─── Events ──────────────────────────────────────────────────────────────────

export function useEvents() {
  const { user } = useAuth()
  const [events,  setEvents]  = useState<Event[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    setLoading(true)
    const unsub = eventsService.subscribe(user.uid, data => {
      setEvents(data)
      setLoading(false)
    })
    return unsub
  }, [user])

  const create = (data: Omit<Event, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) =>
    eventsService.create(user!.uid, data)

  const update = (id: string, data: Partial<Event>) =>
    eventsService.update(user!.uid, id, data)

  const remove = (id: string) =>
    eventsService.delete(user!.uid, id)

  return { events, loading, create, update, remove }
}

// ─── Checklist ───────────────────────────────────────────────────────────────

export function useChecklist(eventId: string) {
  const { user } = useAuth()
  const [items,   setItems]   = useState<ChecklistItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user || !eventId) return
    const unsub = checklistService.subscribe(user.uid, eventId, data => {
      setItems(data)
      setLoading(false)
    })
    return unsub
  }, [user, eventId])

  const create = (data: Omit<ChecklistItem, 'id' | 'userId' | 'createdAt'>) =>
    checklistService.create(user!.uid, data)

  const update = (id: string, data: Partial<ChecklistItem>) =>
    checklistService.update(user!.uid, id, data)

  const remove = (id: string) =>
    checklistService.delete(user!.uid, id)

  return { items, loading, create, update, remove }
}

// ─── Retreat ─────────────────────────────────────────────────────────────────

export function useRetreat(eventId: string) {
  const { user } = useAuth()
  const [participants, setParticipants] = useState<RetreatParticipant[]>([])
  const [loading,      setLoading]      = useState(true)

  useEffect(() => {
    if (!user || !eventId) return
    const unsub = retreatService.subscribe(user.uid, eventId, data => {
      setParticipants(data)
      setLoading(false)
    })
    return unsub
  }, [user, eventId])

  const create = (data: Omit<RetreatParticipant, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) =>
    retreatService.create(user!.uid, data)

  const update = (id: string, data: Partial<RetreatParticipant>) =>
    retreatService.update(user!.uid, id, data)

  const remove = (id: string) =>
    retreatService.delete(user!.uid, id)

  // Financial summary
  const summary = {
    total:    participants.reduce((s, p) => s + p.totalAmount, 0),
    paid:     participants.filter(p => p.paymentStatus === 'pago').reduce((s, p) => s + p.totalAmount, 0),
    pending:  participants.filter(p => p.paymentStatus === 'pendente').reduce((s, p) => s + p.totalAmount, 0),
    overdue:  participants.filter(p => p.paymentStatus === 'atrasado').reduce((s, p) => s + p.totalAmount, 0),
    count:    participants.length,
    approved: participants.filter(p => p.participantStatus === 'aprovado').length,
  }

  return { participants, loading, create, update, remove, summary }
}

// ─── All Retreat Participants (for global financial dashboard) ────────────────

export function useAllParticipants() {
  const { user } = useAuth()
  const [participants, setParticipants] = useState<RetreatParticipant[]>([])
  const [loading,      setLoading]      = useState(true)

  useEffect(() => {
    if (!user) return
    const unsub = retreatService.subscribeAll(user.uid, data => {
      setParticipants(data)
      setLoading(false)
    })
    return unsub
  }, [user])

  return { participants, loading }
}

// ─── Leaders ─────────────────────────────────────────────────────────────────

export function useLeaders() {
  const { user } = useAuth()
  const [leaders,  setLeaders] = useState<Leader[]>([])
  const [loading,  setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    const unsub = leadersService.subscribe(user.uid, data => {
      setLeaders(data)
      setLoading(false)
    })
    return unsub
  }, [user])

  const create = (data: Omit<Leader, 'id' | 'userId' | 'createdAt'>) =>
    leadersService.create(user!.uid, data)

  const update = (id: string, data: Partial<Leader>) =>
    leadersService.update(user!.uid, id, data)

  const remove = (id: string) =>
    leadersService.delete(user!.uid, id)

  return { leaders, loading, create, update, remove }
}

// ─── Ideas ───────────────────────────────────────────────────────────────────

export function useIdeas() {
  const { user } = useAuth()
  const [ideas,   setIdeas]   = useState<Idea[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    const unsub = ideasService.subscribe(user.uid, data => {
      setIdeas(data)
      setLoading(false)
    })
    return unsub
  }, [user])

  const create = (data: Omit<Idea, 'id' | 'userId' | 'createdAt'>) =>
    ideasService.create(user!.uid, data)

  const update = (id: string, data: Partial<Idea>) =>
    ideasService.update(user!.uid, id, data)

  const remove = (id: string) =>
    ideasService.delete(user!.uid, id)

  return { ideas, loading, create, update, remove }
}
