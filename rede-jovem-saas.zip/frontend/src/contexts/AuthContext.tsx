// src/contexts/AuthContext.tsx
import React, { createContext, useContext, useEffect, useState } from 'react'
import { type User } from 'firebase/auth'
import { authService, type ChurchProfile } from '@/services/authService'

interface AuthContextValue {
  user:    User | null
  profile: ChurchProfile | null
  loading: boolean
  login:         (email: string, password: string) => Promise<void>
  register:      (email: string, password: string, churchName: string) => Promise<void>
  logout:        () => Promise<void>
  resetPassword: (email: string) => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user,    setUser]    = useState<User | null>(null)
  const [profile, setProfile] = useState<ChurchProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsub = authService.onAuthChanged(async u => {
      setUser(u)
      if (u) {
        const p = await authService.getProfile(u.uid)
        setProfile(p)
      } else {
        setProfile(null)
      }
      setLoading(false)
    })
    return unsub
  }, [])

  const login = async (email: string, password: string) => {
    const u = await authService.login(email, password)
    const p = await authService.getProfile(u.uid)
    setProfile(p)
  }

  const register = async (email: string, password: string, churchName: string) => {
    const u = await authService.register(email, password, churchName)
    const p = await authService.getProfile(u.uid)
    setProfile(p)
  }

  const logout = async () => {
    await authService.logout()
    setUser(null)
    setProfile(null)
  }

  const resetPassword = (email: string) => authService.resetPassword(email)

  return (
    <AuthContext.Provider value={{ user, profile, loading, login, register, logout, resetPassword }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
