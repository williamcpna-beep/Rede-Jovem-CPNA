# 🔥 CPN Rede Jovem — SaaS de Gestão de Eventos

Sistema SaaS completo para gestão de eventos de igrejas, com autenticação, multi-tenancy e banco de dados real.

---

## 🏗️ Arquitetura

```
rede-jovem-saas/
├── frontend/                    # React + Vite + Tailwind
│   └── src/
│       ├── components/
│       │   └── layout/
│       │       └── AppLayout.tsx     # Sidebar + header responsivo
│       ├── contexts/
│       │   └── AuthContext.tsx       # Auth state global
│       ├── hooks/
│       │   └── useFirestore.ts       # Hooks reativos para cada coleção
│       ├── pages/
│       │   ├── AuthPage.tsx          # Login / Cadastro / Reset
│       │   ├── DashboardPage.tsx     # Métricas + gráficos
│       │   ├── EventsPage.tsx        # CRUD de eventos
│       │   ├── RetreatPage.tsx       # Módulo de retiro + inscrições
│       │   ├── FinancialPage.tsx     # Painel financeiro + carnê
│       │   ├── ChecklistPage.tsx     # Checklist por evento
│       │   ├── LeadersPage.tsx       # Controle de líderes
│       │   └── IdeasPage.tsx         # Banco de ideias
│       └── services/
│           ├── firebase.ts           # Inicialização Firebase
│           ├── authService.ts        # Auth helpers
│           └── firestoreService.ts   # CRUD tipado por coleção
├── backend/
│   ├── firestore.rules               # Regras de segurança
│   └── firestore.indexes.json        # Índices compostos
└── firebase.json                     # Config de deploy
```

### Multi-tenancy

Cada igreja é um "tenant" isolado. Todos os dados ficam em:

```
/tenants/{userId}/events/{eventId}
/tenants/{userId}/checklist/{itemId}
/tenants/{userId}/participants/{participantId}
/tenants/{userId}/leaders/{leaderId}
/tenants/{userId}/ideas/{ideaId}
```

As regras do Firestore garantem que **nenhuma igreja acessa dados de outra**.

---

## 🚀 Setup Local (Passo a Passo)

### 1. Criar projeto Firebase

1. Acesse [console.firebase.google.com](https://console.firebase.google.com)
2. Clique em **"Adicionar projeto"** → dê um nome (ex: `rede-jovem-saas`)
3. Ative o **Google Analytics** (opcional)
4. No menu lateral → **Authentication** → **Primeiros passos**
5. Em **Sign-in method** → ative **E-mail/senha**
6. No menu lateral → **Firestore Database** → **Criar banco de dados**
   - Escolha modo **Produção**
   - Selecione a região mais próxima (ex: `southamerica-east1`)
7. No menu lateral → **Configurações do projeto** ⚙️ → **Seus apps**
   - Clique em `</>` (Web)
   - Registre o app e copie o `firebaseConfig`

### 2. Clonar e configurar

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/rede-jovem-saas.git
cd rede-jovem-saas/frontend

# Instale as dependências
npm install

# Configure as variáveis de ambiente
cp .env.example .env.local
# Edite .env.local com seus dados do Firebase
```

### 3. Subir as regras do Firestore

```bash
# Na raiz do projeto
npm install -g firebase-tools
firebase login
firebase use --add   # selecione seu projeto
firebase deploy --only firestore
```

### 4. Rodar localmente

```bash
cd frontend
npm run dev
# Acesse http://localhost:5173
```

---

## 🌐 Deploy em Produção

### Opção A: Vercel (Recomendado para frontend)

```bash
cd frontend
npm run build        # gera a pasta dist/

# Pelo site vercel.com:
# 1. "Import Git Repository"
# 2. Selecione seu repositório
# 3. Framework: Vite
# 4. Root Directory: frontend
# 5. Em "Environment Variables" adicione todas as VITE_FIREBASE_*
# 6. Deploy!
```

### Opção B: Firebase Hosting

```bash
cd frontend
npm run build

# Da raiz:
firebase deploy --only hosting
```

---

## 🔐 Segurança

As regras do Firestore (`backend/firestore.rules`) garantem:

- ✅ Cada usuário só lê/escreve seus próprios dados
- ✅ Nenhum dado é público
- ✅ Validação no servidor (não depende só do frontend)

---

## 📊 Funcionalidades Implementadas

| Módulo         | Status | Destaques                                          |
|----------------|--------|----------------------------------------------------|
| Autenticação   | ✅      | Login, cadastro, reset de senha, proteção de rotas |
| Multi-tenancy  | ✅      | Dados isolados por userId no Firestore             |
| Dashboard      | ✅      | Métricas, gráfico de status, eventos em risco      |
| Eventos        | ✅      | CRUD completo, status automático, progresso %      |
| Retiro         | ✅      | Inscrições, responsável menor, ficha financeira    |
| Carnê          | ✅      | Parcelas automáticas, marcação de pago             |
| Financeiro     | ✅      | Gráfico pizza, tabela geral, gestão de carnê       |
| Checklist      | 🔧      | Hook pronto, UI a implementar (mesmo padrão)       |
| Ideias         | 🔧      | Hook pronto, UI a implementar                      |
| Líderes        | 🔧      | Hook pronto, UI a implementar                      |
| Dark Mode      | ✅      | Tema escuro nativo                                 |
| Responsivo     | ✅      | Mobile + desktop                                   |

---

## 🛣️ Roadmap (Próximas Features)

- [ ] Push notifications (Firebase Cloud Messaging)
- [ ] Relatórios em PDF
- [ ] Planos pagos (Free / Pro) via Stripe
- [ ] Convite de líderes por e-mail
- [ ] App mobile (React Native ou PWA)

---

## 💡 Stack Técnica

| Camada     | Tecnologia                    |
|------------|-------------------------------|
| Frontend   | React 18 + Vite + TypeScript  |
| Estilo     | Tailwind CSS 3 (dark theme)   |
| Roteamento | React Router 6                |
| Auth       | Firebase Authentication       |
| Banco      | Cloud Firestore (NoSQL)       |
| Gráficos   | Recharts                      |
| Ícones     | Lucide React                  |
| Deploy     | Vercel + Firebase Hosting     |

---

## 📞 Suporte

Dúvidas? Abra uma issue no repositório ou entre em contato.

**CPN Rede Jovem** — Sistema desenvolvido com ❤️ para servir igrejas jovens.
